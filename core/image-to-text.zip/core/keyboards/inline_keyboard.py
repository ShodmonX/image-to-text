from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

help_button = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(
                text="Yordam",
                url="https://t.me/Shodmon_Xolmurodov_bot"
            )
        ]
    ]
)

